#pragma once

#include <SFML/Graphics.hpp>

class Application{
    private:
        sf::RenderWindow mainwindow_;

        sf::RectangleShape rectangle_;
        sf::CircleShape circle_;
        sf::ConvexShape polygon_;

        sf::Texture texture_;
        sf::RectangleShape zmx_;
        sf::Sprite sprite_;

    public:
        Application();

        bool IsRunning() const;

        void Tick();

    private:
        void HandleResize(const sf::Event& event);
        void HandleFocus(const sf::Event& event) ;
        void HandleKeyPressed(const sf::Event& event) ;
        void HandleKeyReleased(const sf::Event& event) ;
        void HandleMouseButtonPressed(const sf::Event& event) ;
        void HandleMouseWheelMoved(const sf::Event& event) ;
        void HandleEvent(const sf::Event& event, sf::RenderWindow& window);
        
        void ProcessEvents();
        void Update();
        void Render();


};