#include "Application.h"
#include <iostream>

Application::Application():     //创建窗口
    mainwindow_(sf::VideoMode(1920, 1080), L"千恋万花", sf::Style::Default)
{

    mainwindow_.setFramerateLimit(60);

    mainwindow_.setKeyRepeatEnabled(false);   
    //禁用长按按键等于多次触发按键，让void Application::HandleKeyPressed函数只能检测一次按下，而不是长按就一直检测
    sf::Mouse::setPosition({960,540},mainwindow_);  //设置开局鼠标位置

    rectangle_.setSize({200,100});
    rectangle_.setPosition({100,200});
    rectangle_.setFillColor(sf::Color::Blue);
    rectangle_.setOutlineThickness(5);   //设置边框厚度(像素,正数是向外拓展，负数相反)
    rectangle_.setOutlineColor(sf::Color::Red);   //设置边框颜色

    circle_.setRadius(100);
    circle_.setPosition({400,200});
    circle_.setPointCount(100);   //设置绘制圆形点的数量，默认是30
    circle_.setFillColor(sf::Color(32,231,143,255));  //设置颜色，括号里分别为(R,G,B,不透明度)不透明度不写时默认255，最高255

    polygon_.setPointCount(4);   //手动自定义凸多边形
    polygon_.setPoint(0,{0,0});
    polygon_.setPoint(1,{100,0});
    polygon_.setPoint(2,{120,100});
    polygon_.setPoint(3,{20,80});
    polygon_.setPosition({100,600});

    texture_.loadFromFile("assets/charactors/zmx.png");     //设置纹理
    if(!texture_.loadFromFile("assets/charactors/zmx.png")){      //判断纹理文件是否存在
        std::cout<<"not found texture"<<'\n';
    }

    texture_.setSmooth(true);     //设置纹理为平滑

    zmx_.setSize({320,320});
    zmx_.setPosition({500,600});
    zmx_.setTexture(&texture_);      //设置纹理
    zmx_.setFillColor(sf::Color::Blue);     //设置颜色，会像加了某色滤镜一样
    //zmx_.setTexture(nullptr);    //删除形状纹理

    sprite_.setTexture(texture_);    //设置精灵
    sprite_.setPosition(900,600);    
    sprite_.setScale({0.5,0.5});      //缩放精灵
    //注意，精灵无法清空纹理，因为精灵不能用指针，用的是引用，引用不能为空
}

bool Application::IsRunning() const    //判断是否运行
{
    return mainwindow_.isOpen();
}

void Application::Tick(){    //主循环
    ProcessEvents();
    Update();
    Render();
}

void Application::ProcessEvents()    //处理事件
{
    sf::Event event;
    while(mainwindow_.pollEvent(event)){ 
        HandleEvent(event, mainwindow_);
        }
}

void Application::Update(){     //上传
    if(sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Left)){   //实时检测是否某按键被按下
        std::cout<<"Left Arrow Key"<<"\n";
    }
    if(sf::Mouse::isButtonPressed(sf::Mouse::Button::Right)){   //实时检测是否某鼠标键被按下
        std::cout<<"Right Mouse Is Held"<<"\n";
    }
    sf::Vector2i position = sf::Mouse::getPosition(mainwindow_);   //实时输出鼠标位置
    std::cout << position.x << ", " << position.y << '\n';
}

void Application::Render(){    //刷新
    mainwindow_.clear();

    mainwindow_.draw(rectangle_);
    mainwindow_.draw(circle_);
    mainwindow_.draw(polygon_);
    mainwindow_.draw(zmx_);
    mainwindow_.draw(sprite_);

    mainwindow_.display();
}

void Application::HandleResize(const sf::Event& event) { 
    std::cout << "new size " << event.size.width << ", " << event.size.height << '\n';
}

void Application::HandleFocus(const sf::Event& event) {
    if (event.type == sf::Event::LostFocus) {
        std::cout << "Focus Lost\n";
    }
    else if (event.type == sf::Event::GainedFocus) {
        std::cout<<"Focus Gained"<<'\n';
    }
}

void Application::HandleKeyPressed(const sf::Event& event) {
    if (event.key.code == sf::Keyboard::W) {
        std::cout << "w\n";
    }
}

void Application::HandleKeyReleased(const sf::Event& event) {
    if (event.key.code == sf::Keyboard::W) {
        std::cout << "w\n";
    }
}

void Application::HandleMouseButtonPressed(const sf::Event& event) {
    if (event.mouseButton.button == sf::Mouse::Left) {
        std::cout << "l " << event.mouseButton.x << ", " << event.mouseButton.y << '\n';
    }
}

void Application::HandleMouseWheelMoved(const sf::Event& event) {
    std::cout << "Wheel delta: " << event.mouseWheel.delta << '\n';
    std::cout << "Wheel at " << event.mouseWheel.x << ", " << event.mouseWheel.y << '\n';
}

void Application::HandleEvent(const sf::Event& event, sf::RenderWindow& window) {
    switch (event.type) {
        case sf::Event::Resized:       HandleResize(event);        break;
        case sf::Event::GainedFocus:   HandleFocus(event);   break;
        case sf::Event::LostFocus:   HandleFocus(event);   break;
        case sf::Event::KeyPressed:    HandleKeyPressed(event);    break;
        case sf::Event::KeyReleased:   HandleKeyReleased(event);   break;
        case sf::Event::MouseButtonPressed: HandleMouseButtonPressed(event); break;
        case sf::Event::MouseWheelMoved:   HandleMouseWheelMoved(event);    break;
        case sf::Event::Closed: window.close(); break;
        default: break;  // 不关心的事件类型直接忽略
    }
}