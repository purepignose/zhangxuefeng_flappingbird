#include "Application.h"
#include <iostream>

Application::Application()     //创建窗口
    : mainwindow_(sf::VideoMode(1920, 1080), L"千恋万花", sf::Style::Default)
{
    mainwindow_.setFramerateLimit(60);
}

bool Application::IsRunning() const    //判断是否运行
{
    return mainwindow_.isOpen();
}

void Application::Tick(){    //主循环
    ProcessEvents();
    Update();
    Render();
}

void Application::ProcessEvents()    //处理事件
{
    sf::Event event;
    while(mainwindow_.pollEvent(event)){ 
        HandleEvent(event, mainwindow_);
        }
}

void Application::Update(){     //上传

}

void Application::Render(){    //刷新
    mainwindow_.clear();
    mainwindow_.display();
}

void Application::HandleResize(const sf::Event& event) { 
    std::cout << "new size " << event.size.width << ", " << event.size.height << '\n';
}

void Application::HandleFocus(const sf::Event& event) {
    if (event.type == sf::Event::LostFocus) {
        std::cout << "Focus Lost\n";
    }
    else if (event.type == sf::Event::GainedFocus) {
        std::cout<<"Focus Gained"<<'\n';
    }
}

void Application::HandleKeyPressed(const sf::Event& event) {
    if (event.key.code == sf::Keyboard::W) {
        std::cout << "w\n";
    }
}

void Application::HandleKeyReleased(const sf::Event& event) {
    if (event.key.code == sf::Keyboard::W) {
        std::cout << "w\n";
    }
}

void Application::HandleMouseButtonPressed(const sf::Event& event) {
    if (event.mouseButton.button == sf::Mouse::Left) {
        std::cout << "l " << event.mouseButton.x << ", " << event.mouseButton.y << '\n';
    }
}

void Application::HandleMouseWheelMoved(const sf::Event& event) {
    std::cout << "Wheel delta: " << event.mouseWheel.delta << '\n';
    std::cout << "Wheel at " << event.mouseWheel.x << ", " << event.mouseWheel.y << '\n';
}

void Application::HandleEvent(const sf::Event& event, sf::RenderWindow& window) {
    switch (event.type) {
        case sf::Event::Resized:       HandleResize(event);        break;
        case sf::Event::GainedFocus:   HandleFocus(event);   break;
        case sf::Event::LostFocus:   HandleFocus(event);   break;
        case sf::Event::KeyPressed:    HandleKeyPressed(event);    break;
        case sf::Event::KeyReleased:   HandleKeyReleased(event);   break;
        case sf::Event::MouseButtonPressed: HandleMouseButtonPressed(event); break;
        case sf::Event::MouseWheelMoved:   HandleMouseWheelMoved(event);    break;
        case sf::Event::Closed: window.close(); break;
        default: break;  // 不关心的事件类型直接忽略
    }
}