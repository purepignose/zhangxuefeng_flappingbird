#include "Application.h"

int main(){
    Application app;

    while (app.IsRunning()){
        app.Tick();
    }
    
}